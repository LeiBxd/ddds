import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SLAU {

    private static final double eps = 0.00000001; // EPSILON - погрешность при сравнении чисел
    private static final int MaxIterationsAmount = 10;
    private double[][] matrix; // matrix хранит в себе матрицу коэффициентов и свободных членов
    private int n; // n - количество уравнений в системе
    private int m; // m - количество коэффициентов + 1 (свободные члены)
    private double precision; // требуемая точность
    private double[] solutions; // решение системы (если оно есть)
    private double[] currentIteration; // приближения решений, получаемые на текущей итерации

    private String status = "";
    // status - информационная переменная, которая содержит одно из сообщений:
    // 1. "Невозможно решить итерационным методом"
    // 2. "Метод расходится"

    private int[] nonZeroTemplate; // nonZeroTemplate - хранит в себе первую перестановку
    private boolean isAEqualToB(double a, double b) { // Проверяет два числа на равенство в пределах погрешности EPSILON
        return Math.abs(a - b) < eps;
    }

    /*
    Читает файл вида
    1 строка: n m
    2 строка: precision(точность)
    3 строка - k строку: матрица
     */
    public void init(String pathToFile) throws FileNotFoundException { // init читает данные из файла и заполняет matrix, n, m

        Scanner scanner = new Scanner(new FileInputStream(pathToFile)); // Создаем Scanner и открываем pathToFile
        readSizes(scanner); // Читаем первую строчку из файла, содержащую размеры n и m
        String line = scanner.nextLine(); // Читаем очередную строку из файла
        Pattern pattern = Pattern.compile("-?\\d+\\.\\d+"); // Создаем регулярное выражение (Pattern), которое может распознавать дробные числа со знаком
        Matcher matcher = pattern.matcher(line); // Получаем объект matcher из Pattern
        matcher.find(); // Находим следующее дробное число
        precision = Double.parseDouble(line.substring(matcher.start(), matcher.end())); // Вырезаем из строки line дробное число
        matrix = new double[n][]; // инициализируем матрицу matrix

        for (int i = 0; i < n; i++) {
            matrix[i] = readEquation(scanner); // Заполняем матрицу matrix
        }
        scanner.close(); // Закрываем файл
    }
    private void readSizes(Scanner scanner) { // читает n и m со Scanner при помощи регулярного выражения
        String line = scanner.nextLine(); // Читаем очередную строку из файла
        Pattern pattern = Pattern.compile("\\d+"); // Создаем регулярное выражение (Pattern), которое может распознавать целые числа
        Matcher matcher = pattern.matcher(line); // Получаем объект matcher из Pattern
        matcher.find(); // Находим следующее целое число
        n = Integer.parseInt(line.substring(matcher.start(), matcher.end())); // Вырезаем из строки line целое число
        matcher.find(); // Находим следующее целое число
        m = Integer.parseInt(line.substring(matcher.start(), matcher.end())); // Вырезаем из строки line целое число
    }
    private double[] readEquation(Scanner scanner) { // упрощение чтения кода
        String line = scanner.nextLine(); // Читаем очередную строку из файла
        Pattern pattern = Pattern.compile("-?\\d+\\.?\\d*"); // Создаем регулярное выражение (Pattern)
        Matcher matcher = pattern.matcher(line); // Получаем объект matcher из Pattern, который непосредственно находит дробные числа в строке line

        double[] equation = new double[m]; // инициализируем массив equation, который будет заполнен коэффициентами и свободным членом из строки файла line
        for (int i = 0; i < m; i++) { // Находим в цикле все дробные числа строки и записываем в equation
            matcher.find(); // Находим следующее дробное число
            equation[i] = Double.parseDouble(line.substring(matcher.start(), matcher.end()));
        }
        return equation; // Вырезаем из строки line дробное число
    }

    //ищет перестановку, для которой выполняется условие отсутствия нулей на главной диагонали
    public boolean prepareMatrix() {
        double[] rowSums = new double[n];
        //Вычисляет сумму всех элементов в каждой строке матрицы, кроме последнего (ответа). Сумма хранится в массиве rowsums.
        for (int i = 0; i < n; i++) {
            rowSums[i] = 0.0;
            for (int j = 0; j < m - 1; j++) {
                rowSums[i] += matrix[i][j];
            }
        }

        int[] template = new int[n];
        for (int i = 0; i < n; i++) {
            template[i] = i; // template - содержит перестановку индексов строк
        }

        if (permute(template, rowSums, 0)) { // permute - рекурсивно находит все возможные перестановки строк
            // переставляем строки в соответствии с найденной перестановкой
            applyTemplate(template);
            System.out.println("Матрица с переставленными строками");
            System.out.println(format());
            return true;
        } else {
            // permute возвращает false если хотя бы одно условие не выполняется
            if (nonZeroTemplate != null) {
                // применяем nonZeroTemplate над исходной матрицей matrix
                applyTemplate(nonZeroTemplate);
            } else {
                status = "Данную систему решить итерационным методом нельзя"; // выставляем статус
            }
            System.out.println("Матрица на последней итерации перестановок");
            System.out.println(format());
            return false;
        }
    }

    private void applyTemplate(int[] template) { // Метод applyTemplate() переставляет строки матрицы matrix в соответствии с перестанавкой template
        double[][] initialMatrix = new double[n][];
        for (int i = 0; i < n; i++) {
            initialMatrix[i] = new double[m];
            for (int j = 0; j < m; j++) {
                initialMatrix[i][j] = matrix[i][j]; // initailMatrix - содержит в себе исходную полную копию исходной матрицы
            }
        }
        for (int i = 0; i < n; i++) {
            matrix[i] = initialMatrix[template[i]]; // процесс перестановки
        }
    }

    private boolean permute(int[] permutation, double[] rowSums, int k) { // Метод permute() - рекурсивно ищет перестановки. Параметр k - индекс элемента в permutation

        if (k == n - 1) { // условие выхода из рекурсии
            return isValidPermutation(permutation, rowSums); // проверяем условия при данной перестановке
        }

        for (int i = k; i < n; i++) { // цикл, переставляющий каждый элемент с индексом большим или равным k
            swap(permutation, i, k); // переставляем два элемента в массиве
            if (permute(permutation, rowSums, k + 1)) { // рекурсивный вызов permute с параметром k + 1
                return true;
            }
            swap(permutation, k, i); // переставляем возвращаем элементы на изначальные позиции
        }
        return false; // подходящая перестановка с элементов с k по n - 1 при фиксированных с 0 по k - 1 не была найдена
    }
    private void swap(int[] array, int i, int j) { // Метод swap() осуществляет перестановку двух элементов массива array с индексами i и j
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    /*проверяет два условия для переданной перестановки.
    Если оба условия выполняются для данной перестановки, метод возвращает true. Кроме того, если была найдена первая перестановка строк, для которой на главной
    диагонали нет нулей, запоминаем ее в nonZeroTempalate*/
    private boolean isValidPermutation(int[] permutation, double[] rowSums) { // Метод isValidPermutation() проверяет оба условия для перестановки permutation
        if (nonZeroTemplate == null && isNoZeroOnMainDiagonal(permutation)) {
            nonZeroTemplate = new int[n];
            for (int i = 0; i < n; i++) {
                nonZeroTemplate[i] = permutation[i]; // Если была найдена первая перестановка строк, для которой на главной диагонали нет нулей, запоминаем ее в nonZeroTempalate
            }
        }
        return isNoZeroOnMainDiagonal(permutation) && isDusCondition(permutation, rowSums); // вызываем функции проверки условий
    }


    private boolean isNoZeroOnMainDiagonal(int[] permutation) { //- проверяет, отсутствуют ли нули на главной диагонали матрицы, используя заданную перестановку.
        //В цикле for последовательно перебираются все элементы главной диагонали матрицы.
        for (int i = 0; i < n; i++) {
            //Для каждого элемента производится проверка на равенство нулю, используя метод isAEqualToB()
            if (isAEqualToB(matrix[permutation[i]][i], 0.0)) {
                //Если хотя бы один элемент главной диагонали равен нулю, цикл прерывается и метод возвращает значение false (перестановка не удовлетворяет условию).
                return false;
            }
        }
        //Если все элементы главной диагонали отличны от нуля, метод возвращает true (перестановка удовлетворяет условию).
        return true;
    }

    /*проверяет, выполняется ли достаточное условие сходимости для заданной матрицы и,
    если ДУС не нарушается, возвращает true. Если ДУС нарушается, возвращает false. Аргументами метода служат массив перестановок и массив суммы модулей
    коэф. строк кроме диаг.*/
    private boolean isDusCondition(int[] permutation, double[] rowSums) {

        // sum - сумма модулей
        double sum;
        // Объявление переменной boolean notEqualFlag, которая будет использоваться для хранения результатов проверки ДУС на строки матрицы.
        boolean notEqualFlag = false;
        // true означает, что была найдена хотя бы одна строка, для которой ДУС выполняется строго
        // false - нет ни одной строки, для которой ДУС бы выполнялся строго
        for (int i = 0; i < n; i++) {
//            Проверяет, выполняется ли ДУС для данной строки, сравнивая модуль главного диагонального элемента с разностью sum и этого элемента.
            sum = rowSums[permutation[i]] - matrix[permutation[i]][i];

            //Если разность больше eps (эпсилон), устанавливает notEqualFlag в true - это означает, что для хотя бы одной строки ДУС выполняется строго.
            if (Math.abs(matrix[permutation[i]][i]) - sum > eps) {
                notEqualFlag = true;

            /*Если разность меньше или равна eps, проверяет, равны ли модуль главного диагонального элемента и значение переменной sum. Если нет, функция возвращает false,
             что означает, что ДУС нарушается.*/
            } else if (!isAEqualToB(Math.abs(matrix[permutation[i]][i]), sum)) {
                return false; // Если ДУС нарушется, завершаем выполнение функции и возращаем false
            }
        }

        return notEqualFlag; // Нет строки, для которой ДУС нарушался бы -> ответ хранится в переменной notEqualFlag.
        // Если была найдена хотя бы одна строка, для которой ДУС выполняется строго, она будет равна true.
    }

    // решение
    public void solution(boolean dus) {
        //Создаем массив решений размером n и заполняем его нулями.
        solutions = new double[n];
        // Создаем массив текущей итерации размером n
        currentIteration = new double[n];

        for (int j = 0; j < n; j++) {
            solutions[j] = 0.0;
        }
        // если DUS выполняется, то решаем без контроля
        if (dus) {
            solutionWithoutControl();
        // Если DUS не выполняется, то решаем с контролем
        } else {
            SolutionWithControl();
        }
    }

    // решение без контроля
    public void solutionWithoutControl() {
        // максимальная разница между текущей и предыдущей итерациями, равная -1
        double maxDifference = -1.0;
        /*Входим в цикл while, условие которого - модуль значения переменной максимальная разница между текущей и предыдущей итерациями
        больше или равен значению precision (точности).*/
        while (Math.abs(maxDifference) >= precision) {
            //В теле цикла вызываем метод iteration() и присваиваем его результат переменной maxDifference.
            maxDifference = iteration();
        }
    }

    // решение с контролем
    public void SolutionWithControl() {
        //k - номер текущей итерации.
        int k = 1;
        // значение модуля разности на предыдущей итерации
        double oldDifference = -1.0;
        // максимальное по модулю отклонение
        double maxDifference = -1.0;
        while (Math.abs(maxDifference) >= precision) {
            //Если k больше максимального количества итераций MaxIterationsAmount, то установить переменную status в "Метод расходится" и выйти из цикла
            if (k > MaxIterationsAmount) {
                status = "Метод расходится";
                break;
            }
            //Выполнить метод iteration и присвоить результат maxDifference
            maxDifference = iteration();
            //Если oldDifference равно -1, то присвоить ему значение maxDifference
            if (isAEqualToB(oldDifference, -1.0)) {
                oldDifference = maxDifference;
            // Если разность maxDifference и oldDifference больше eps, то установить переменную status в "Метод расходится" и выйти из цикла
            } else if (maxDifference - oldDifference > eps) {
                status = "Метод расходится. Немонотонное убывания модуля разностей обнаружено на итерации: " + k;
                break;
            //Иначе присвоить oldDifference значение maxDifference и увеличить k на 1.
            } else {
                oldDifference = maxDifference;
            }
            k++;
        }
    }

    private double iteration() { // метод iteration() проводит очередную итерацию по методу Гаусcа-Зейделя
        double maxDifference = -1.0; // maxDifference хранит модуль наибольшей разницы для данной итерации

        // На каждой итерации метода происходит проход по всем строкам системы и вычисление очередной приближенной величины для каждой неизвестной переменной x[i]
        for (int i = 0; i < n; i++) {
            currentIteration[i] = findXi(i); // findXi() реализует итерационную формулу Гаусса-Зейделя

            //роизводит проверку на уменьшение наибольшей разницы (maxDifference) между предыдущими и текущими решениями
            if (Math.abs(solutions[i] - currentIteration[i]) - maxDifference > eps) {
                maxDifference = Math.abs(solutions[i] - currentIteration[i]); // обновляем, если нужно maxDifference
            }
        }
        // Решения на текущей итерации записываются в массив solutions и метод возвращает значение maxDifference
        for (int i = 0; i < n; i++) {
            solutions[i] = currentIteration[i]; // После завершения итерации необходимо перенести найденные решение в solutions
        }
        return maxDifference;
    }

    private double findXi(int i) { // метод findXi() находит очередное приближение решения Xi, используя итерационную формулу Гаусса-Зейделя
        double xi = matrix[i][m - 1]; // xi хранит результат выполнение функции. инициализируем свободным членом

        /* Проходится по всем элементам строки и, в зависимости от того, больше ли индекс j, чем i, выбирает решение с предыдущей или текущей итерации
        для умножения на соответствующий коэффициент из матрицы*/
        for (int j = 0; j < n; j++) { // проходимся по строке i
            if (i == j) {
                continue; // в случае совпадения индексов i и j пропускаем итерацию
            }

            if (j > i) {
                xi += -1.0 * matrix[i][j] * solutions[j]; // если индекс j > i, то нужно использовать решение с предыдущей итерации, т.е. solutions
            } else  {
                xi += -1.0 * matrix[i][j] * currentIteration[j]; // если же индес j < i, то нужно использовать решение с текущей итерации, т.е. currentIteration
            }
        }

        return xi / matrix[i][i];
    }

    public String format() { // Представляет матрицу matrix в виде строки
        String result = "";
        for (int i = 0; i < n; i++) {
            result += formatEquation(matrix[i]);
        }
        return result; // В цикле форматируем каждую строку матрицы matrix, на каждой итерации добавляем к result
    }


    private String formatEquation(double[] equation) { // Представляет строку equation в виде строки. использует String.format() для форматированного вида
        String result = "";

        for (int i = 0; i < m; i++) { // В цикле форматируем каждую элемент строки матрицы matrix, используя String.format
            result += String.format("%18.6e", equation[i]);

            if (i == m - 1) {
                result += System.lineSeparator();
            }
        }
        return result;
    }


    public String getSolutions() { // Возвращает строку, содержащую форматированный вывод массива решений solutions.
        String result = "";

        for (int i = 0; i < m - 1; i++) {
            result += String.format("%18.6e", solutions[i]);
        }
        return result; // В цикле форматируем каждую элемент массива неизвестных solutions, используя String.format()
    }

    public String getStatus() {
        return status; // Возвращает информационное сообщение
    }
}

