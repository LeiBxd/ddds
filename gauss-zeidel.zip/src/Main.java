import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) {
        SLAU matrix = new SLAU(); // Создаем объект класса SLAU

        try {
            matrix.init("src/data.txt");
        } catch (FileNotFoundException e) {
            System.out.println("Файла не существует");
            return; // Вызываем метод init с переданным именем файла для заполнения матрицы matrix из файла
            // Если из метода init выброшено исключение FileNotFoundException -> выводим сообщение и завершаем программу
        }

        System.out.println("Матрица, прочитанная из файла: "); // Выводим пояснительное сообщение
        System.out.println(matrix.format()); // Вызываем матрицу в виде форматированной строки. Результат печатаем на экран

        if (matrix.prepareMatrix()) {
            System.out.println("ДУС выполняется");
            matrix.solution(true); // Запускаем алгоритм Гаусса-Зейделя
        }
        else {
            if (matrix.getStatus().equals("")) {
                System.out.println("ДУС не выполняется");
                matrix.solution(false); // Запускаем алгоритм Гаусса-Зейделя
                if (!matrix.getStatus().equals("")) { // Проверяем, что решение найдено

                    System.out.println(matrix.getStatus());
                    return; // Выводим сообщение на экран и завершаем выполнение программы
                }
            }
            else {
                System.out.println(matrix.getStatus());
                return;
            }
        }
        String solutions = matrix.getSolutions();
        System.out.println("Решения:");
        System.out.println(solutions); // Получаем строку и выводим ее на экран
    }
}
